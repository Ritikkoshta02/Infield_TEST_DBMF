'''
Created on 27-Jun-2013

@author: sukanta
'''
import re
import subprocess

sleep_time = 1


def header(ip_f,op_f):
    line = ip_f.readline()            
    token = line.split()
    if token[0] != 'dimension' or len(token) != 3:
        print 'First line should be \'dimension m n\''
        return
    else:
        op_f.write('from Biochip import *\n\n\n')
        op_f.write('root = Tk()\n')
        op_f.write('B = Biochip(root,%d,%d)\n'%(int(token[1]),int(token[2])))
        op_f.write('print \'clock = %d \' %B.get_clock()\n')
        op_f.write('#----------------------------------------------------------------\n')
        
    line = ip_f.readline()
    token = line.split()
    if token[0] != 'clock' or len(token) != 2:
        print 'Second line should be \'clock n\''
        return
    else:
        global sleep_time
        sleep_time = float(token[1])
        
    line = ip_f.readline() 
    instr_line = re.compile('[a-z_]+\s*\([\s*\d+\s*,\s*]+\s*\w+\s*\)').findall(line)
    #print instr_line
    for instr in instr_line:
        gen(instr,op_f)
        
def gen(instr,f):
    obj = re.compile('[a-z_]+').match(instr)
    if obj == None:
        print 'Invalid syntax: ' + instr
        exit() 
    
    opcode = obj.group()    
    operands = re.compile('(\d+|\w+)').findall(instr[obj.end() + 1 :])
    
    if opcode == 'dispense' and len(operands) == 2:
        r = int(operands[0].strip())
        c = int(operands[1].strip())
        f.write('B.dispense_droplet(%d,%d)\n' % (r, c))
    elif opcode == 'move' and len(operands) == 4:
        rold = int(operands[0].strip())
        cold = int(operands[1].strip())
        rnew = int(operands[2].strip())
        cnew = int(operands[3].strip())
        f.write('B.move_droplet(%d,%d,%d,%d)\n' % (rold, cold, rnew, cnew))
    elif opcode == 'mix_split' and len(operands) == 5:
        r1 = int(operands[0].strip())
        c1 = int(operands[1].strip())
        r2 = int(operands[2].strip())
        c2 = int(operands[3].strip())
        t = int(operands[4].strip())
        f.write('B.instantiate_mixer(%d,%d,%d,%d,%d)\n' % (r1, c1, r2, c2, t))
    elif opcode == 'waste' and len(operands) == 2:
        r = int(operands[0].strip())
        c = int(operands[1].strip())
        f.write('B.delete_droplet(%d,%d)\n' % (r, c))
    elif opcode == 'output' and len(operands) == 2:
        r = int(operands[0].strip())
        c = int(operands[1].strip())
        f.write('B.delete_droplet(%d,%d)\n' % (r, c))
    elif opcode == 'reagent' and len(operands) == 3:
        pass
    elif opcode == 'waste_reservior' and len(operands) == 2:
        pass
    elif opcode == 'end':
        pass
    else:
        print 'Invalid Command:' + instr
        exit()
    
            
        
def common(op_f):
    op_f.write('B.run_mixer()\n')
    op_f.write('B.advance_clock()\n')
    op_f.write('time.sleep(%f)\n' %sleep_time)
    op_f.write('print \'clock = %d \' %B.get_clock()\n')
    

def new_interpreter(filename):
    ip_f = open(filename,'r')
    op_f = open('output.py','w')
    
    header(ip_f,op_f)  
     
    c_time = 0      #start time     
    for line in ip_f:
        if not line.strip():
            continue            #skipping blank lines
        time = re.compile('\d+').match(line)
        if time == None:
            print 'Invalid syntax: ' + line
            exit()
        
        op_time = int(time.group())     #operation execution time
        if c_time > op_time:
            print 'Timing violation'
            return
        while c_time < op_time:
            common(op_f)
            c_time = c_time + 1
        
        c_time = c_time + 1  
          
        instr_line = re.compile('[a-z_]+\s*\([\s*\d+\s*,\s*]+\s*\w+\s*\)').findall(line)
        
        for instr in instr_line:
            gen(instr,op_f)
                
        common(op_f)

    
    op_f.write('B.mainloop()\n')
    ip_f.close()
    op_f.close()
    
    
    
   
        
new_interpreter('atsp.dmfb')
subprocess.call(["python", "output.py"])


#def interpreter(filename):
#    ip_f = open(filename,'r')
#    op_f = open('output.py','w')
#    
#    header(ip_f,op_f)  
#     
#    c_time = 0      #start time     
#    for line in ip_f:
#        if not line.strip():
#            continue
#        token = line.split(':')
#        if len(token) != 2:
#            print 'Invalid syntax: ' + line
#            exit()
#        
#        op_time = int(token[0])     #operation execution time
#        if c_time > op_time:
#            print 'Timing violation'
#            return
#        while c_time < op_time:
#            common(op_f)
#            c_time = c_time + 1
#        
#        c_time = c_time + 1    
#        instr_line = token[1].split(';')
#        for instr in instr_line:
#            instr_token = re.split(',|\(|\)',instr)
#            if instr_token[0].strip()=='dispense':
#                r = int(instr_token[1].strip())
#                c = int(instr_token[2].strip())
#                op_f.write('B.dispense_droplet(%d,%d)\n'%(r,c))
#            elif instr_token[0].strip()=='move':
#                rold = int(instr_token[1].strip())
#                cold = int(instr_token[2].strip())
#                rnew = int(instr_token[3].strip())
#                cnew = int(instr_token[4].strip())
#                op_f.write('B.move_droplet(%d,%d,%d,%d)\n'%(rold,cold,rnew,cnew))
#            elif instr_token[0].strip()=='mix_split':
#                r1 = int(instr_token[1].strip())
#                c1 = int(instr_token[2].strip())
#                r2 = int(instr_token[3].strip())
#                c2 = int(instr_token[4].strip())
#                t = int(instr_token[5].strip())
#                op_f.write('B.instantiate_mixer(%d,%d,%d,%d,%d)\n'%(r1,c1,r2,c2,t))
#            elif instr_token[0].strip()=='waste':
#                r = int(instr_token[1].strip())
#                c = int(instr_token[2].strip())
#                op_f.write('B.delete_droplet(%d,%d)\n'%(r,c))
#            elif instr_token[0].strip()=='output':
#                r = int(instr_token[1].strip())
#                c = int(instr_token[2].strip())
#                op_f.write('B.delete_droplet(%d,%d)\n'%(r,c))
#            elif instr_token[0].strip()=='end':
#                pass
#            else:
#                print 'Invalid Command:' + line
#                exit()
#                
#        common(op_f)
#
#    
#    op_f.write('B.mainloop()\n')
#    ip_f.close()
#    op_f.close()
    
