'''
Created on 04-Jul-2013
@author: sukanta
'''
import sys
import re

def V_make_list(size):
    mylist = []
    for i in range(size):
        mylist.append(droplet())
    return mylist

def V_create_matrix(rows, cols):
    matrix = []
    for i in range(rows):
        matrix.append(V_make_list(cols))
    return matrix

def V_print_matrix(mat):
    for row in mat:
        for e in row:
            print e,
        print 

def V_copy_matrix(mat):
    cp_mat = []
    for row in mat:
        elist = []
        for e in row:
            elist.append(e)
        cp_mat.append(elist)
    return cp_mat

class droplet:
    def __init__(self):
        self.id = None      #None implies no droplet
        self.conc = []
        
class mixer:
    def __init__(self,mixer_type,start,end,r1,c1,r2,c2):
        self.mtype = mixer_type # mtype is the type of mixer horizontal(14) = 1 * 4, vertical(41) = 4 * 1
        self.s_time = start     # start time of mixer
        self.e_time = end       # end time of mixer
        self.d1r = r1           # location of first droplet  
        self.d1c = c1
        self.d2r = r2           # location of first droplet  
        self.d2c = c2
    def show(self):
        print 'mixer_type = %d'%self.mtype
        print 'start time = %d end time = %d' %(self.s_time,self.e_time)
        print 'droplet- 1 (%d,%d)'%(self.d1r,self.d1c)
        print 'droplet- 2 (%d,%d)'%(self.d2r,self.d2c)

class Biochip_V:
    def __init__(self,r,c):
        self.row = r
        self.col = c
        self.op_reservior = []
        self.ip_reservior = []
        self.waste_reservior = []
        self.c_time = 0
        self.biochip = V_create_matrix(r+2,c+2)
        self.mixer_table = []
        self.__ID = 0       # ID of droplets for  sequence graph
        self.c_time = 0     # time when last verification done
        
    def __get_new_ID(self):
        self.__ID = self.__ID + 1
        return self.__ID
        
    def __droplet_loc_is_valid(self,x,y):
        if x not in range(1,self.row+1):
            return False
        if y not in range(1,self.col+1):
            return False
        
    def __FC_between_2_droplets(self,x1,y1,x2,y2):
            if  abs(x1 - x2) >= 2 or abs(y1-y2) >=2:
                return True
            else:
                return False
    
    def set_resevior_V(self,r,c,reservior_type,name = None):
        
        if self.__droplet_loc_is_valid(r,c) == False :
            print 'set_resevior_V - 1: Cannot set reservoir at wrong location (%d,%d)\n' %(r,c)
            sys.exit()
        
        if (r not in [1,self.row]) and (c not in [1,self.col]):
            print 'set_resevior_V - 2: Cannot set reservoir at wrong location (%d,%d)\n' %(r,c)
            sys.exit()
            
        # Check for Fluidic Constraint (FC) violation with other reserviors
        for reservior in self.ip_reservior:
            if self.__FC_between_2_droplets(reservior[0],reservior[1],r,c) == False:
                print 'set_resevior_V - 3: Fluidic constraint violaton between (%d,%d) and (%d,%d)\n' %(reservior[0],reservior[1],r,c)
                sys.exit()
        for reservior in self.op_reservior:
            if self.__FC_between_2_droplets(reservior[0],reservior[1],r,c) == False:
                print 'set_resevior_V - 4: Fluidic constraint violaton between (%d,%d) and (%d,%d)\n' %(reservior[0],reservior[1],r,c)
                sys.exit()
        for reservior in self.waste_reservior:
            if self.__FC_between_2_droplets(reservior[0],reservior[1],r,c) == False:
                print 'set_resevior_V - 5: Fluidic constraint violaton between (%d,%d) and (%d,%d)\n' %(reservior[0],reservior[1],r,c)
                sys.exit()
           
        # Store reservior location           
        if reservior_type == 'waste_reservior':    #waste reservior
            self.waste_reservior.append((r,c,'Waste'))
            
        elif reservior_type == 'op_reservior':    #output reservior
            self.op_reservior.append((r,c,'Output'))
            
        elif reservior_type == 'reagent':    #output reservior
            if name == None:
                print 'set_reservior_V - 6: reagent name should be present'
                sys.exit()
            self.ip_reservior.append((r,c,'reagent',name))
        else:
            print 'set_reservior_V - 7: Invalid command' 
            
    def verify_dispense_insrt(self, dispense_instr, insrtuction_line):
        # verifying dispense(r,c) operation
        for instr in dispense_instr:
            #checking for valid reagent dispenser
            flag = 0
            for reagent_dispr in self.ip_reservior:
                if instr == (reagent_dispr[0],reagent_dispr[1]):
                    flag =  1
            if flag == 0:
                print 'verify_dispense_insrt - 1: Trying to dispense from invalid inpur reservior - %s' %insrtuction_line
                sys.exit()
            
            # dispenser location is valid now
            # test for presence of droplet at dispense location
            (r,c) = (instr[0], instr[1])
            if self.biochip[r][c].id != None:
                print 'verify_dispense_insrt - 2: Droplet present - can not dispense in (%d,%d) - %s' %(r,c,insrtuction_line)
                sys.exit()
            # instantiate droplet with new ID and check FC
            self.biochip[r][c].id = self.__get_new_ID()
            if self.check_FC(r, c) == False:
                print 'verify_dispense_insrt - 3: Fluidic constraint violated in dispensing - %s' %insrtuction_line
                sys.exit()
                
    def verify_mix_split_insrt(self, mix_split_instr, insrtuction_line):
        for instr in mix_split_instr:
            (d1r,d1c,d2r,d2c,mixing_time)= instr
            if self.__droplet_loc_is_valid(d1r, d1c) == False or self.__droplet_loc_is_valid(d2r, d2c) == False:
                print 'verify_mix_split_insrt - 1: Invalid droplet location - %s' % insrtuction_line
                sys.exit()
            if self.droplet_in_active_mixers(d1r, d1c) == True or self.droplet_in_active_mixers(d2r, d2c) == True:
                print 'verify_mix_split_insrt - 2: Droplet is in active mixer - %s' %insrtuction_line
                sys.exit()
            if self.biochip[d1r][d1c].id == None or self.biochip[d2r][d2c].id == None:
                print 'verify_mix_split_insrt - 3: Droplet is not present - %s' %insrtuction_line
                sys.exit() 
            if mixing_time % 6 != 0:
                print 'verify_mix_split_insrt - 4: Invalid mixing time - %s' %insrtuction_line
                sys.exit()
                    
            # Instantiate mixers
            if d1r == d2r and abs(d1c - d2c) == 3:   # 1*4 mixer
                if d1c < d2c:
                    m = mixer(14,self.c_time,self.c_time + mixing_time,d1r,d1c,d2r,d2c)   #instantiate
                else:
                    m = mixer(14,self.c_time,self.c_time + mixing_time,d2r,d2c,d1r,d1c)
                self.mixer_table.append(m)      #register mixer
            elif d1c == d2c and abs(d1r - d2r) == 3:    # 4*1 mixer
                if d1r < d2r:
                    m = mixer(41,self.c_time,self.c_time + mixing_time,d1r,d1c,d2r,d2c) 
                else:
                    m = mixer(41,self.c_time,self.c_time + mixing_time,d2r,d2c,d1r,d1c)
                self.mixer_table.append(m)      #register mixer
            else:
                print 'verify_mix_split_insrt - 5: Mixer cannot be instantiated - %s' %insrtuction_line
                sys.exit()
                
    def verify_move_instr(self,move_instr,insrtuction_line):
        print move_instr
        # check dynamic FC
        for instr in move_instr:
            (d1r,d1c,d2r,d2c)= instr
            if self.__droplet_loc_is_valid(d1r, d1c) == False or self.__droplet_loc_is_valid(d2r, d2c) == False:
                print 'verify_move_instr - 1: Invalid droplet location - %s' % insrtuction_line
                sys.exit()
            if self.droplet_in_active_mixers(d1r, d1c) == True:
                print 'verify_move_instr - 2: Droplet (%d,%d) is in active mixer - %s' %(d1r,d1c,insrtuction_line)
                sys.exit()
            if self.biochip[d1r][d1c].id == None:
                print 'verify_move_instr - 3: Droplet (%d,%d) is not present - %s' %(d1r,d1c,insrtuction_line)
                sys.exit() 
            if abs(d1r - d2r) > 1 or abs(d1c - d2c) > 1:
                print 'verify_move_instr - 4: Invalid movement from (%d,%d) -> (%d,%d) - %s' %(d1r,d1c,d2r,d2c,insrtuction_line)
                sys.exit()
            if self.biochip[d2r][d2c].id != None:
                print 'verify_move_instr - 5: cannot move to an occupied location(%d,%d) - %s' %(d2r,d2c,insrtuction_line)   
                sys.exit()
            if self.droplet_in_active_mixers(d2r, d2c) == True:
                print 'verify_move_instr - 6: Destination (%d,%d) is in active mixer - %s' %(d2r,d2c,insrtuction_line)
                sys.exit()
            
            # save id
            ID = self.biochip[d1r][d1c].id
            # move
            self.biochip[d1r][d1c].id = None
            self.biochip[d2r][d2c].id = ID
            # check DFC
            if self.check_FC(d2r,d2c) == False:
                print 'verify_move_instr - 7: dynamic fulidic constraint violated - %s'%insrtuction_line
                sys.exit()
            # reset movement
            self.biochip[d2r][d2c].id = None
            self.biochip[d1r][d1c].id = ID
            
        # check static FC
        for instr in move_instr:
            (d1r,d1c,d2r,d2c)= instr
            # save id
            ID = self.biochip[d1r][d1c].id
            # move
            self.biochip[d1r][d1c].id = None
            self.biochip[d2r][d2c].id = ID
            # check DFC
            if self.check_FC(d2r,d2c) == False:
                print 'verify_move_instr - 8: static fulidic constraint violated - %s'%insrtuction_line
                sys.exit()
                
    def verify_waste_insrt(self, waste_instr, insrtuction_line):
        # verifying dispense(r,c) operation
        for instr in waste_instr:
            #checking for valid reagent dispenser
            flag = 0
            for waste_dispr in self.waste_reservior:
                if instr == (waste_dispr[0],waste_dispr[1]):
                    flag =  1
            if flag == 0:
                print 'verify_waste_insrt - 1: Trying to dispense from invalid waste reservior - %s' %insrtuction_line
                sys.exit()
            
            # dispenser location is valid now
            
            (r,c) = (instr[0], instr[1])
            # check for the presence of waste droplet
            if self.biochip[r][c].id == None:
                print 'verify_waste_insrt - 2: No droplet in (%d,%d) - %s' %(r,c,insrtuction_line)
                sys.exit()
            
            # dispense waste
            self.biochip[r][c].id = None
            self.biochip[r][c].conc = []
            
    def verify_op_insrt(self, op_instr, insrtuction_line):
        # verifying dispense(r,c) operation
        for instr in op_instr:
            #checking for valid reagent dispenser
            flag = 0
            for op_dispr in self.op_reservior:
                if instr == (op_dispr[0],op_dispr[1]):
                    flag =  1
            if flag == 0:
                print 'verify_op_insrt - 1: Trying to dispense from invalid output reservior - %s' %insrtuction_line
                sys.exit()
            
            # dispenser location is valid now
            
            (r,c) = (instr[0], instr[1])
            # check for the presence of waste droplet
            if self.biochip[r][c].id == None:
                print 'verify_op_insrt - 2: No droplet in (%d,%d) - %s' %(r,c,insrtuction_line)
                sys.exit()
            
            # dispense output
            self.biochip[r][c].id = None
            self.biochip[r][c].conc = []
            
        
            
    def verify_line(self,line):
        # get curr_time
        time = re.compile('\d+').match(line)
        if time == None:
            print 'Invalid syntax: ' + line
            sys.exit()
        
        op_time = int(time.group())     #operation execution time
        if self.c_time > op_time:
            print 'verify_line - 1: Timing violation in :%s' %line
            sys.exit()
        
        self.c_time = op_time   # Set current time
        self.delete_expired_mixers(self.c_time)    #delete all expired mixers
        
        (dispense_instr, mix_split_instr, move_instr, waste_instr, op_instr) = self.group_instructions(line)
        # verify each operation
        
        #-------------------------------------------------------------------------------------
        # verifying dispense(r,c) operation
        self.verify_dispense_insrt(dispense_instr,line)
        #-------------------------------------------------------------------------------------
        # verifying mix-split operation
        self.verify_mix_split_insrt(mix_split_instr,line)
                
        #-------------------------------------------------------------------------------------
        # verifying move operation
        self.verify_move_instr(move_instr,line)
        
        #-------------------------------------------------------------------------------------
        # verifying waste operation
        self.verify_waste_insrt(waste_instr, line)
        #-------------------------------------------------------------------------------------
        # verifying output operation
        self.verify_op_insrt(op_instr, line)               
        
        
        self.c_time = self.c_time + 1
        return
    
    def droplet_in_active_mixers(self,r,c):
        for mixer in self.mixer_table:
            if (mixer.d1r,mixer.d1c) == (r,c) or (mixer.d2r,mixer.d2c) == (r,c):
                return True
        return False
    
    def check_FC(self,r,c):
        '''This functions checks violation of FC of droplet (r,c) with other droplets currently present'''
        if self.__droplet_loc_is_valid(r,c) == False :
            print 'check_FC - 1: Droplet location (%d,%d) is outside of Biochip\n' %(r,c)
            sys.exit()
                
        for x in range(1,self.row + 1):
            for y in range(1,self.col + 1):
                if self.biochip[x][y].id == None:     # None implies no droplet
                    pass
                elif (x,y) != (r,c):    # droplet present
                    if self.__FC_between_2_droplets(x,y,r,c) == False:  # check for same droplet and violation of FC
                        return False
                else:
                    pass
        return True
                        
    def group_instructions(self,line):
        dispense_instr = []
        mix_split_instr = []
        move_instr = []
        waste_instr = []
        op_instr = []
        
        instr_line = re.compile('[a-z_]+\s*\([\s*\d+\s*,\s*]+\s*\w+\s*\)').findall(line)
        
        for instr in instr_line:
            obj = re.compile('[a-z_]+').match(instr)
            if obj == None:
                print 'group_instruction: Invalid syntax: ' + instr
                sys.exit() 
            
            print instr
            opcode = obj.group()    
            operands = re.compile('(\d+|\w+)').findall(instr[obj.end() + 1 :])
            
            if opcode == 'dispense' and len(operands) == 2:
                r = int(operands[0].strip())
                c = int(operands[1].strip())
                dispense_instr.append((r,c))
            elif opcode == 'mix_split' and len(operands) == 5:
                r1 = int(operands[0].strip())
                c1 = int(operands[1].strip())
                r2 = int(operands[2].strip())
                c2 = int(operands[3].strip())
                t = int(operands[4].strip())
                mix_split_instr.append((r1, c1, r2, c2, t))            
            elif opcode == 'move' and len(operands) == 4:
                rold = int(operands[0].strip())
                cold = int(operands[1].strip())
                rnew = int(operands[2].strip())
                cnew = int(operands[3].strip())
                move_instr.append((rold, cold, rnew, cnew))
            elif opcode == 'waste' and len(operands) == 2:
                r = int(operands[0].strip())
                c = int(operands[1].strip())
                waste_instr.append((r,c))
            elif opcode == 'output' and len(operands) == 2:
                r = int(operands[0].strip())
                c = int(operands[1].strip())
                op_instr.append((r,c))
            else:
                print 'group_instruction: Invalid Command:' + instr
                sys.exit()  
                
        return (dispense_instr, mix_split_instr, move_instr, waste_instr, op_instr)
    
    def delete_expired_mixers(self,curr_time):
        ''' create new droplets (change id)  and delete expired mixers'''
        
        active_mixers = []
        for m in self.mixer_table:  
            m.show()     
            if curr_time > m.e_time:
                #creating new droplets
                new_id = self.__get_new_ID()
                self.biochip[m.d1r][m.d1c].id = new_id
                self.biochip[m.d2r][m.d2c].id = new_id                
            else:
                active_mixers.append(m)
        
        self.mixer_table = active_mixers 

B_V = Biochip_V(8,8)
#(dispense_instr, mix_split_instr, move_instr, waste_instr, op_instr) = B_V.group_instructions('1    dispense(1,1) dispense(5,1) move(1,1,2,1) move(5,6,4,6) mix_split(2,1,5,1,12) waste(6,8) output(8,3)')
#print dispense_instr, mix_split_instr, move_instr, waste_instr, op_instr
B_V.set_resevior_V(1,2,'reagent','Sample')
print B_V.ip_reservior
B_V.biochip[1][1].id = 1
B_V.biochip[1][4].id = 2
B_V.verify_line('1  mix_split(1,1,1,4,12) ')
B_V.biochip[4][3].id = 3
B_V.biochip[3][3].id = 4
B_V.verify_line('14  move(1,4,2,4) move(3,3,4,3)')
B_V.verify_line('15  mix_split(1,3,4,3,12) ')



